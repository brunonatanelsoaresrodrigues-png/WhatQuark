import { readFileSync } from "fs";

import pino from "pino";
import makeWASocket, {
  UserFacingSocketConfig,
  DisconnectReason,
  WASocket,
  AuthenticationCreds,
  initAuthCreds,
  isJidUser,
  isLidUser,
  isJidGroup,
  isJidBroadcast,
  makeCacheableSignalKeyStore,
  BufferJSON,
  WAMessage,
  WAMessageKey,
  downloadMediaMessage,
  getContentType,
  jidNormalizedUser,
  jidDecode,
  makeInMemoryStore,
  SignalDataSet,
  AnyMessageContent,
  proto,
  Browsers,
  fetchLatestWaWebVersion,
  WAVersion,
  MessageRetryMap
} from "whaileys";
import { LRUCache } from "lru-cache";
import { Boom } from "@hapi/boom";
import { HttpsProxyAgent } from "https-proxy-agent";
import NodeCache from "node-cache";

import Whatsapp from "../../../models/Whatsapp";
import Message from "../../../models/Message";
import { getIO } from "../../../libs/socket";
import { logger } from "../../../utils/logger";
import AppError from "../../../errors/AppError";
import StoreWppSessionKeys from "../../../services/WppKeyServices/StoreWppSessionKeys";
import GetWppSessionKeys from "../../../services/WppKeyServices/GetWppSessionKeys";
import { getRedisClient } from "../../../libs/redisStore";
import {
  SendMessageOptions,
  ProviderMessage,
  ProviderMediaInput,
  SendMediaOptions,
  ProviderContact,
  MessageType,
  MessageAck,
  HistorySyncCursor,
  HistorySyncProgress,
  HistorySyncResult
} from "../types";
import { WhatsappProvider } from "../whatsappProvider";
import { sleep } from "../../../utils/sleep";
import {
  bestIncomingContactName,
  lidUser
} from "../../../helpers/ContactIdentity";
import { resolveWhatsAppMessageIdentity } from "../../../helpers/WhatsAppMessageIdentity";
import CreateOrUpdateContactService from "../../../services/ContactServices/CreateOrUpdateContactService";
import {
  handleMessage,
  handleMessageAck,
  ContactPayload,
  MessagePayload,
  MediaPayload,
  WhatsappContextPayload
} from "../../../handlers/handleWhatsappEvents";

type WALogger = NonNullable<Parameters<typeof makeInMemoryStore>[0]["logger"]>;

const whaileyLogger = pino({
  level: process.env.WHAILEYS_LOG_LEVEL || "silent"
}) as unknown as WALogger;

type Store = ReturnType<typeof makeInMemoryStore>;

interface Session extends WASocket {
  id: number;
  store?: Store;
}

const sessions = new Map<number, Session>();
const stores = new Map<number, Store>();
const inFlightMessageHandlers = new Set<Promise<void>>();

const msgRetryCounterLRU = new LRUCache<string, number>({
  max: 5000,
  ttl: 600 * 1000,
  allowStale: false,
  updateAgeOnGet: true
});

const msgRetryCounterMap = new Proxy<MessageRetryMap>({} as MessageRetryMap, {
  get(target, prop) {
    if (typeof prop === "string") {
      return msgRetryCounterLRU.get(prop);
    }
    return Reflect.get(target, prop);
  },
  set(target, prop, value) {
    if (typeof prop === "string" && typeof value === "number") {
      msgRetryCounterLRU.set(prop, value);
      return true;
    }
    return Reflect.set(target, prop, value);
  },
  deleteProperty(target, prop) {
    if (typeof prop === "string") {
      msgRetryCounterLRU.delete(prop);
      return true;
    }
    return Reflect.deleteProperty(target, prop);
  },
  has(target, prop) {
    if (typeof prop === "string") {
      return msgRetryCounterLRU.has(prop);
    }
    return Reflect.has(target, prop);
  },
  ownKeys() {
    return Array.from(msgRetryCounterLRU.keys());
  },
  getOwnPropertyDescriptor(target, prop) {
    if (typeof prop === "string" && msgRetryCounterLRU.has(prop)) {
      return {
        configurable: true,
        enumerable: true,
        value: msgRetryCounterLRU.get(prop)
      };
    }
    return undefined;
  }
});

const msgCacheLRU = new LRUCache<string, string>({
  max: 5000,
  ttl: 600 * 1000,
  allowStale: false,
  updateAgeOnGet: true
});

const sentMessagesCache = new NodeCache({
  stdTTL: 60,
  useClones: false
});

const normalizeJid = (jid: string): string => {
  if (!jid) return jid;
  if (!jid.includes("@")) return `${jid}@s.whatsapp.net`;
  return jid.replace(/@c\.us$/i, "@s.whatsapp.net");
};

const msgCache = {
  get: (key: WAMessageKey): proto.IMessage | undefined => {
    const { id } = key;
    if (!id) return undefined;
    const data = msgCacheLRU.get(id);
    if (data) {
      try {
        const msg = JSON.parse(data);
        return msg?.message;
      } catch {
        return undefined;
      }
    }
    return undefined;
  },
  save: (msg: WAMessage) => {
    const { id } = msg.key;
    if (!id) return;
    try {
      msgCacheLRU.set(id, JSON.stringify(msg));
    } catch (e) {
      logger.debug({ info: "Error caching message", messageId: id, err: e });
    }
  }
};

const clearSessionKeys = async (sessionId: number): Promise<void> => {
  const client = getRedisClient();
  if (!client) return;

  try {
    const match = `wpp:${sessionId}:*`;

    const scanAndDelete = async (cursor: string): Promise<void> => {
      const [nextCursor, keys] = await client.scan(
        cursor,
        "MATCH",
        match,
        "COUNT",
        100
      );

      if (keys.length > 0) {
        await client.del(keys);
      }

      if (nextCursor !== "0") {
        await scanAndDelete(nextCursor);
      }
    };

    await scanAndDelete("0");

    logger.info({ info: "Cleared Redis session keys", sessionId });
  } catch (err) {
    logger.error({ info: "Error clearing Redis session keys", sessionId, err });
  }
};

const assertUnique = (sessionId: number) => {
  const wbot = sessions.get(sessionId);

  if (wbot) {
    wbot.ev.removeAllListeners("connection.update");
    sessions.delete(sessionId);
    stores.delete(sessionId);

    wbot.end(undefined);
  }
};

const saveSessionCreds = async (
  whatsapp: Whatsapp,
  creds: AuthenticationCreds
) => {
  try {
    await whatsapp.update({
      session: JSON.stringify(creds, BufferJSON.replacer),
      status: "CONNECTED",
      qrcode: ""
    });

    logger.debug({
      info: "Creds saved to database",
      whatsappId: whatsapp.id
    });
  } catch (err) {
    logger.error({
      info: "Error saving creds to database",
      whatsappId: whatsapp.id,
      err
    });
  }
};

const credsDebounceTimers = new Map<number, NodeJS.Timeout>();
const pendingCredsSaves = new Map<
  number,
  { whatsapp: Whatsapp; creds: AuthenticationCreds }
>();

const flushPendingCredsSave = async (sessionId: number): Promise<void> => {
  const existingTimer = credsDebounceTimers.get(sessionId);
  if (existingTimer) {
    clearTimeout(existingTimer);
    credsDebounceTimers.delete(sessionId);
  }

  const pending = pendingCredsSaves.get(sessionId);
  if (pending) {
    pendingCredsSaves.delete(sessionId);
    await saveSessionCreds(pending.whatsapp, pending.creds);
  }
};

const debouncedSaveCreds = (
  whatsapp: Whatsapp,
  creds: AuthenticationCreds,
  delayMs = 1000
) => {
  const sessionId = whatsapp.id;

  const existingTimer = credsDebounceTimers.get(sessionId);
  if (existingTimer) {
    clearTimeout(existingTimer);
  }

  pendingCredsSaves.set(sessionId, { whatsapp, creds });

  const timer = setTimeout(() => {
    credsDebounceTimers.delete(sessionId);
    pendingCredsSaves.delete(sessionId);
    saveSessionCreds(whatsapp, creds);
  }, delayMs);

  credsDebounceTimers.set(sessionId, timer);
};

const useSessionAuthState = async (whatsapp: Whatsapp) => {
  const sessionId = whatsapp.id;

  const creds = whatsapp.session
    ? JSON.parse(whatsapp.session, BufferJSON.reviver)
    : initAuthCreds();

  return {
    state: {
      creds: creds as AuthenticationCreds,
      keys: {
        get: async (type: string, ids: string[]) => {
          const deviceId = jidDecode(creds?.me?.id)?.device || 1;

          const data = await GetWppSessionKeys({
            connectionId: sessionId,
            deviceId,
            type,
            ids
          });

          return data;
        },
        set: async (data: SignalDataSet) => {
          const deviceId = jidDecode(creds?.me?.id)?.device || 1;

          try {
            for (const [category, categoryData] of Object.entries(data)) {
              if (!categoryData) continue;
              for (const [id, value] of Object.entries(categoryData)) {
                // Sequencial por conexão para evitar deadlocks no índice único
                // durante a rotação simultânea de pre-keys do Signal.
                // eslint-disable-next-line no-await-in-loop
                await StoreWppSessionKeys({
                  connectionId: sessionId,
                  deviceId,
                  type: category,
                  id,
                  value
                });
              }
            }
          } catch (err) {
            logger.error({
              info: "Error setting keys",
              sessionId,
              err
            });
          }
        }
      }
    }
  };
};

const mapMessageType = (msg: WAMessage): MessageType => {
  const messageType = getContentType(msg.message || undefined);

  if (messageType === "audioMessage" && msg.message?.audioMessage?.ptt) {
    return "ptt";
  }

  const typeMap: Record<string, MessageType> = {
    conversation: "chat",
    extendedTextMessage: "chat",
    imageMessage: "image",
    videoMessage: "video",
    audioMessage: "audio",
    documentMessage: "document",
    stickerMessage: "sticker",
    locationMessage: "location",
    contactMessage: "vcard",
    contactsArrayMessage: "vcard"
  };

  return typeMap[messageType || ""] || "chat";
};

const getMessageBody = (msg: WAMessage): string => {
  try {
    const messageType = getContentType(msg.message || undefined);

    if (messageType === "conversation") {
      return msg.message?.conversation || "";
    }

    if (messageType === "extendedTextMessage") {
      return msg.message?.extendedTextMessage?.text || "";
    }

    if (messageType === "imageMessage") {
      return msg.message?.imageMessage?.caption || "";
    }

    if (messageType === "videoMessage") {
      return msg.message?.videoMessage?.caption || "";
    }

    if (messageType === "documentMessage") {
      return msg.message?.documentMessage?.caption || "";
    }

    if (messageType === "contactMessage") {
      return msg.message?.contactMessage?.vcard || "";
    }

    if (messageType === "contactsArrayMessage") {
      const contacts = msg.message?.contactsArrayMessage?.contacts || [];
      return contacts.map(c => c.vcard).join("\n");
    }

    if (messageType === "locationMessage") {
      const location = msg.message?.locationMessage;
      if (!location) return "";

      const gmapsUrl = `https://maps.google.com/maps?q=${location.degreesLatitude}%2C${location.degreesLongitude}&z=17&hl=pt-BR`;
      const description =
        location.name ||
        `${location.degreesLatitude}, ${location.degreesLongitude}`;

      return `${gmapsUrl}|${description}`;
    }

    return "";
  } catch (err) {
    logger.error({ info: "Error getting message body", err });
    return "";
  }
};

const getQuotedMessageId = (msg: WAMessage): string | undefined => {
  const quotedMessageId =
    msg.message?.extendedTextMessage?.contextInfo?.stanzaId ||
    msg.message?.imageMessage?.contextInfo?.stanzaId ||
    msg.message?.videoMessage?.contextInfo?.stanzaId ||
    msg.message?.documentMessage?.contextInfo?.stanzaId ||
    undefined;

  return quotedMessageId;
};

const hasMedia = (msg: WAMessage): boolean => {
  const messageType = getContentType(msg.message || undefined);
  return [
    "imageMessage",
    "videoMessage",
    "audioMessage",
    "documentMessage",
    "stickerMessage"
  ].includes(messageType || "");
};

const mapMessageAck = (status: number | null | undefined): MessageAck => {
  if (status === null || status === undefined) return 0;
  if (status >= 4) return 4;
  if (status >= 3) return 3;
  if (status >= 2) return 2;
  if (status >= 1) return 1;
  return 0;
};

const shouldHandleMessage = (msg: WAMessage): boolean => {
  const messageType = getContentType(msg.message || undefined);
  const validTypes = [
    "conversation",
    "extendedTextMessage",
    "imageMessage",
    "videoMessage",
    "audioMessage",
    "documentMessage",
    "stickerMessage",
    "locationMessage",
    "contactMessage",
    "contactsArrayMessage"
  ];

  if (!validTypes.includes(messageType || "")) return false;

  const body = getMessageBody(msg);
  if (/\u200e/.test(body[0])) return false;

  if (!msg.key.fromMe) return true;

  const allowedFromMeTypes = [
    "locationMessage",
    "conversation",
    "extendedTextMessage",
    "contactMessage"
  ];

  return hasMedia(msg) || allowedFromMeTypes.includes(messageType || "");
};

const convertToMessagePayload = (msg: WAMessage): MessagePayload => {
  const fromJid = msg.key.remoteJid || "";
  const toJid = msg.key.fromMe ? fromJid : msg.key.participant || fromJid;
  const fromMe = msg.key.fromMe || false;

  return {
    id: msg.key.id || "",
    body: getMessageBody(msg),
    fromMe,
    hasMedia: hasMedia(msg),
    type: mapMessageType(msg),
    timestamp: msg.messageTimestamp ? Number(msg.messageTimestamp) : Date.now(),
    from: fromJid,
    to: toJid,
    hasQuotedMsg: Boolean(getQuotedMessageId(msg)),
    quotedMsgId: getQuotedMessageId(msg),
    ack: fromMe ? 1 : 0
  };
};

type ExtendedKey = WAMessageKey &
  Partial<{
    senderPn: string;
    sender_pn: string;
    participantPn: string;
    participant_pn: string;
    peerRecipientPn: string;
    peer_recipient_pn: string;
    recipientPn: string;
    recipient_pn: string;
    senderLid: string;
    sender_lid: string;
    participantLid: string;
    participant_lid: string;
    recipientLid: string;
    recipient_lid: string;
  }>;

type ExtendedContext = proto.IContextInfo &
  Partial<{
    senderLid: string;
    sender_lid: string;
    participantLid: string;
    participant_lid: string;
    recipientLid: string;
    recipient_lid: string;
    senderPn: string;
    sender_pn: string;
    participantPn: string;
    participant_pn: string;
    peerRecipientPn: string;
    peer_recipient_pn: string;
    recipientPn: string;
    recipient_pn: string;
  }>;

const getExtendedContext = (msg: WAMessage): ExtendedContext | undefined => {
  const content = msg.message || {};
  return (content?.extendedTextMessage?.contextInfo ||
    content?.imageMessage?.contextInfo ||
    content?.videoMessage?.contextInfo ||
    content?.documentMessage?.contextInfo ||
    content?.audioMessage?.contextInfo ||
    content?.stickerMessage?.contextInfo ||
    undefined) as ExtendedContext | undefined;
};

const convertToContactPayload = async (
  jid: string,
  msg: WAMessage,
  wbot: Session
): Promise<ContactPayload> => {
  const keyExt = (msg.key || {}) as ExtendedKey;
  const ctx = getExtendedContext(msg);

  const identity = resolveWhatsAppMessageIdentity(
    jid || "",
    keyExt as unknown as Record<string, unknown>,
    ctx as unknown as Record<string, unknown> | undefined,
    Boolean(msg.key.fromMe)
  );
  const { resolvedJid, phoneJid: preferPn, lid } = identity;

  const safeNormalized = (value?: string) => {
    if (!value) return "";
    try {
      return jidNormalizedUser(value);
    } catch {
      return value;
    }
  };

  const normalizedJid = safeNormalized(resolvedJid);

  const contactInfo =
    wbot.store?.contacts?.[resolvedJid] ||
    wbot.store?.contacts?.[normalizedJid];

  const chatInfo =
    wbot.store?.chats?.get?.(resolvedJid) ||
    wbot.store?.chats?.get?.(normalizedJid);

  let profilePicUrl: string | undefined;

  if (normalizedJid) {
    try {
      const url = await wbot.profilePictureUrl(normalizedJid, "image");
      profilePicUrl = url || undefined;
    } catch (err) {
      logger.debug({
        info: "Could not get profile picture",
        jid: normalizedJid,
        err
      });
    }
  }

  if (isJidGroup(resolvedJid)) {
    const groupNumber = normalizedJid.split("@")[0];
    const groupName =
      contactInfo?.name ||
      contactInfo?.notify ||
      chatInfo?.name ||
      (chatInfo as { subject?: string } | undefined)?.subject ||
      groupNumber;

    if (!contactInfo && (!groupName || groupName === groupNumber)) {
      try {
        const meta = await wbot.groupMetadata(normalizedJid);
        const metaName = typeof meta?.subject === "string" ? meta.subject : "";
        if (metaName) {
          return {
            name: metaName,
            number: groupNumber,
            isGroup: true,
            profilePicUrl
          };
        }
      } catch {
        /* ignore */
      }
    }

    return {
      name: groupName,
      number: groupNumber,
      isGroup: true,
      profilePicUrl
    };
  }

  const decoded = jidDecode(resolvedJid);

  const sessionPushName = wbot.user?.name?.trim().toLowerCase();
  const incomingPushName = msg.pushName?.trim();
  const pushName =
    incomingPushName &&
    sessionPushName &&
    incomingPushName.toLowerCase() === sessionPushName
      ? undefined
      : incomingPushName;

  const number =
    (isJidUser(resolvedJid) && decoded?.user) ||
    jidDecode(preferPn || "")?.user ||
    normalizedJid.split("@")[0];

  const lidValue =
    isLidUser(resolvedJid) && decoded?.user ? `${decoded.user}@lid` : lid;

  const providerName = bestIncomingContactName(
    [contactInfo?.name, contactInfo?.notify, pushName],
    number,
    lidValue
  );

  return {
    name: providerName,
    number,
    lid: lidValue,
    isGroup: false,
    profilePicUrl
  };
};

const convertToMediaPayload = async (
  msg: WAMessage,
  wbot: Session
): Promise<MediaPayload | undefined> => {
  if (!hasMedia(msg)) return undefined;

  // TODO save direct to disc using stream
  try {
    const buffer = await downloadMediaMessage(
      msg,
      "buffer",
      {},
      {
        logger: whaileyLogger,
        reuploadRequest: wbot.updateMediaMessage
      }
    );

    const messageType = getContentType(msg.message || undefined);
    const getExtension = (mimetype: string, fallback: string): string =>
      mimetype.split("/")[1]?.split(";")[0] || fallback;

    if (messageType === "imageMessage") {
      const mimetype = msg.message?.imageMessage?.mimetype || "image/jpeg";
      return {
        filename: `image-${Date.now()}.${getExtension(mimetype, "jpg")}`,
        mimetype,
        data: buffer.toString("base64")
      };
    }

    if (messageType === "videoMessage") {
      const mimetype = msg.message?.videoMessage?.mimetype || "video/mp4";
      return {
        filename: `video-${Date.now()}.${getExtension(mimetype, "mp4")}`,
        mimetype,
        data: buffer.toString("base64")
      };
    }

    if (messageType === "audioMessage") {
      const mimetype =
        msg.message?.audioMessage?.mimetype || "audio/ogg; codecs=opus";
      return {
        filename: `audio-${Date.now()}.ogg`,
        mimetype,
        data: buffer.toString("base64")
      };
    }

    if (messageType === "documentMessage") {
      const docMsg = msg.message?.documentMessage;
      const mimetype = docMsg?.mimetype || "application/octet-stream";
      const ext = getExtension(mimetype, "bin");
      return {
        filename: docMsg?.title || `document-${Date.now()}.${ext}`,
        mimetype,
        data: buffer.toString("base64")
      };
    }

    if (messageType === "stickerMessage") {
      const mimetype = msg.message?.stickerMessage?.mimetype || "image/webp";
      return {
        filename: `sticker-${Date.now()}.webp`,
        mimetype,
        data: buffer.toString("base64")
      };
    }

    return {
      filename: "",
      mimetype: "",
      data: buffer.toString("base64")
    };
  } catch (err) {
    logger.error({
      info: "Error downloading media",
      err,
      messageId: msg.key.id
    });

    return undefined;
  }
};

const getMessageData = async (
  msg: WAMessage,
  wbot: Session
): Promise<{
  messagePayload: MessagePayload;
  contactPayload: ContactPayload;
  contextPayload: WhatsappContextPayload;
  mediaPayload: MediaPayload | undefined;
}> => {
  const remoteJid = msg.key.remoteJid || "";
  const isGroup = isJidGroup(remoteJid);

  let contactJid = remoteJid;
  let groupContact;

  if (!msg.key.fromMe && isGroup && msg.key.participant) {
    contactJid = msg.key.participant;
    groupContact = await convertToContactPayload(remoteJid, msg, wbot);
  }

  const contactPayload = await convertToContactPayload(contactJid, msg, wbot);
  const messagePayload = convertToMessagePayload(msg);
  const mediaPayload = await convertToMediaPayload(msg, wbot);

  const contextPayload: WhatsappContextPayload = {
    whatsappId: wbot.id,
    unreadMessages: 0,
    groupContact
  };

  return {
    messagePayload,
    contactPayload,
    contextPayload,
    mediaPayload
  };
};

const getHistoryMessageData = async (
  msg: WAMessage,
  wbot: Session,
  contactCache: Map<string, ContactPayload>
): Promise<{
  messagePayload: MessagePayload;
  contactPayload: ContactPayload;
  contextPayload: WhatsappContextPayload;
  mediaPayload: MediaPayload | undefined;
}> => {
  const remoteJid = msg.key.remoteJid || "";
  const isGroup = isJidGroup(remoteJid);
  const contactJid =
    !msg.key.fromMe && isGroup && msg.key.participant
      ? msg.key.participant
      : remoteJid;

  const identity = resolveWhatsAppMessageIdentity(
    contactJid,
    msg.key as unknown as Record<string, unknown>,
    getExtendedContext(msg) as unknown as Record<string, unknown> | undefined,
    Boolean(msg.key.fromMe)
  );
  // A LID-only message and a later message carrying its PN must not share the
  // same cache entry; the latter is what allows the old contact to be merged.
  const contactCacheKey = `${contactJid}|${identity.phoneJid || ""}`;

  let contactPayload = contactCache.get(contactCacheKey);
  if (!contactPayload) {
    contactPayload = await convertToContactPayload(contactJid, msg, wbot);
    contactCache.set(contactCacheKey, contactPayload);
  }

  let groupContact: ContactPayload | undefined;
  if (isGroup) {
    groupContact = contactCache.get(remoteJid);
    if (!groupContact) {
      groupContact = await convertToContactPayload(remoteJid, msg, wbot);
      contactCache.set(remoteJid, groupContact);
    }
  }

  return {
    messagePayload: convertToMessagePayload(msg),
    contactPayload,
    contextPayload: {
      whatsappId: wbot.id,
      unreadMessages: 0,
      groupContact
    },
    mediaPayload: await convertToMediaPayload(msg, wbot)
  };
};

const getWbot = (sessionId: number): Session => {
  const wbot = sessions.get(sessionId);

  if (!wbot) {
    throw new AppError("ERR_WAPP_NOT_INITIALIZED");
  }

  return wbot;
};

const removeSession = async (whatsappId: number): Promise<void> => {
  await flushPendingCredsSave(whatsappId);

  const wbot = sessions.get(whatsappId);
  if (wbot) {
    wbot.ev.removeAllListeners("connection.update");
    wbot.ev.removeAllListeners("creds.update");
    wbot.ev.removeAllListeners("messages.upsert");
    wbot.ev.removeAllListeners("messages.update");
    wbot.ev.removeAllListeners("message-receipt.update");
    wbot.ev.removeAllListeners("presence.update");
    wbot.ev.removeAllListeners("groups.upsert");
    wbot.ev.removeAllListeners("groups.update");
    wbot.ev.removeAllListeners("group-participants.update");
    wbot.ev.removeAllListeners("contacts.upsert");
    wbot.ev.removeAllListeners("contacts.update");
    wbot.ev.removeAllListeners("contacts.phone-number-share");
    wbot.ev.removeAllListeners("chats.upsert");
    wbot.ev.removeAllListeners("chats.update");
    wbot.ev.removeAllListeners("chats.delete");
    wbot.ev.removeAllListeners("blocklist.set");
    wbot.ev.removeAllListeners("blocklist.update");

    try {
      wbot.end(undefined);
    } catch (e) {
      logger.debug({ info: "Error ending wbot", err: e });
    }

    try {
      wbot.ws?.removeAllListeners?.();
      await wbot.ws?.close?.();
    } catch (e) {
      logger.debug({ info: "Error closing websocket", err: e });
    }
  }

  sessions.delete(whatsappId);
  stores.delete(whatsappId);
};

const init = async (whatsapp: Whatsapp): Promise<void> => {
  const sessionId = whatsapp.id;
  const io = getIO();

  const { state } = await useSessionAuthState(whatsapp);
  const store = makeInMemoryStore({ logger: whaileyLogger });
  stores.set(sessionId, store);

  let waVersionToUse: WAVersion | undefined;

  if (process.env.WA_SOCKET_VERSION) {
    try {
      const parsed = JSON.parse(process.env.WA_SOCKET_VERSION) as number[];
      if (Array.isArray(parsed) && parsed.length >= 3) {
        waVersionToUse = parsed as WAVersion;
        logger.info({
          info: "Using WA_SOCKET_VERSION from env",
          version: waVersionToUse.join(".")
        });
      }
    } catch {
      logger.warn({
        info: "Failed to parse WA_SOCKET_VERSION, fetching latest"
      });
    }
  }

  if (!waVersionToUse) {
    try {
      const fetchedVersionData = await fetchLatestWaWebVersion({});
      if (fetchedVersionData?.version) {
        waVersionToUse = fetchedVersionData.version;
        logger.info({
          info: "Using latest WA Web version",
          version: waVersionToUse.join(".")
        });
      }
    } catch (e) {
      logger.warn({ info: "Failed to fetch latest WA version, using default" });
    }
  }

  const connOptions: UserFacingSocketConfig = {
    logger: whaileyLogger,
    browser: Browsers.ubuntu(process.env.WHATSAPP_BROWSER_NAME || "Chrome"),
    emitOwnEvents: true,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(
        state.keys,
        whaileyLogger,
        new NodeCache({
          useClones: false,
          stdTTL: 60 * 60,
          checkperiod: 60 * 5
        })
      )
    },
    shouldSyncHistoryMessage: () => false,
    shouldIgnoreJid: jid => {
      if (typeof jid !== "string") return false;
      return (
        isJidBroadcast(jid) ||
        jid?.endsWith("newsletter") ||
        jid === "status@broadcast"
      );
    },
    syncFullHistory: false,
    version: waVersionToUse,
    msgRetryCounterMap,
    markOnlineOnConnect: false,
    fireInitQueries: true,
    generateHighQualityLinkPreview: true,
    linkPreviewImageThumbnailWidth: 192,
    defaultQueryTimeoutMs: 60_000,
    connectTimeoutMs: 25_000,
    retryRequestDelayMs: 500,
    transactionOpts: { maxCommitRetries: 10, delayBetweenTriesMs: 3000 },
    sentMessagesCache,
    getMessage: async (key: WAMessageKey) => {
      const cached = msgCache.get(key);
      if (cached) return cached;

      const msg = store.messages[key.remoteJid!]?.get(key.id!);
      if (msg?.message) return msg.message;

      return undefined;
    }
  };

  const proxyAddress = process.env.PROXY_ADDRESS || "";
  if (proxyAddress) {
    const proxyAuth = process.env.PROXY_AUTH || "";
    const proxyUrl = proxyAuth
      ? `http://${proxyAuth}@${proxyAddress}`
      : `http://${proxyAddress}`;

    connOptions.agent = new HttpsProxyAgent(proxyUrl);
    connOptions.fetchAgent = new HttpsProxyAgent(proxyUrl);
  }

  assertUnique(sessionId);

  const wbot = makeWASocket(connOptions) as Session;
  wbot.id = sessionId;
  wbot.store = store;

  store.bind(wbot.ev);

  sessions.set(sessionId, wbot);

  wbot.ev.on("creds.update", () => {
    debouncedSaveCreds(whatsapp, state.creds);
  });

  wbot.ev.on("contacts.phone-number-share", async ({ lid, jid }) => {
    const number = jidDecode(jid || "")?.user || "";
    const normalizedLid = lidUser(lid) ? `${lidUser(lid)}@lid` : "";
    if (!number || !normalizedLid) return;

    try {
      await CreateOrUpdateContactService({
        name: number,
        number,
        lid: normalizedLid,
        isGroup: false
      });
    } catch (err) {
      logger.warn({
        info: "Could not consolidate shared WhatsApp phone identity",
        err
      });
    }
  });

  wbot.ev.on("messages.upsert", async ({ messages, type }) => {
    messages.forEach(msg => {
      msgCache.save(msg);
      logger.debug({
        info: "Message received",
        sessionId,
        type,
        messageTimestamp: msg.messageTimestamp,
        status: msg.status,
        messageType: Object.keys(msg.message || {})
      });
    });

    const validMessages = messages.filter(msg => {
      if (!msg.message || !shouldHandleMessage(msg)) return false;

      if (type === "notify") return true;

      if (type === "append" && msg.key.fromMe) return true;

      return false;
    });

    if (validMessages.length === 0) return;

    const handling = Promise.all(
      validMessages.map(async msg => {
        try {
          const {
            messagePayload,
            contactPayload,
            contextPayload,
            mediaPayload
          } = await getMessageData(msg, wbot);

          await handleMessage(
            messagePayload,
            contactPayload,
            contextPayload,
            mediaPayload
          );
        } catch (err) {
          logger.error(err, "Error handling message upsert");
        }
      })
    ).then(() => undefined);
    inFlightMessageHandlers.add(handling);
    try {
      await handling;
    } finally {
      inFlightMessageHandlers.delete(handling);
    }
  });

  wbot.ev.on("connection.update", async update => {
    const { connection, lastDisconnect, qr } = update;

    if (connection === "close") {
      const statusCode = (lastDisconnect?.error as Boom)?.output?.statusCode;
      const errorMessage =
        (lastDisconnect?.error as Boom)?.output?.payload?.message ||
        (lastDisconnect?.error as Error)?.message ||
        "";

      if (errorMessage === "Intentional Logout") {
        await whatsapp.update({
          status: "DISCONNECTED",
          qrcode: "",
          retries: 0
        });

        const updatedWhatsapp = await Whatsapp.findByPk(sessionId);
        if (updatedWhatsapp) {
          io.to("admin").emit("whatsappSession", {
            action: "update",
            session: updatedWhatsapp
          });
        }

        logger.info({ info: "Session intentionally logged out", sessionId });

        await clearSessionKeys(sessionId);

        await removeSession(sessionId);
        return;
      }

      if (statusCode === DisconnectReason.loggedOut) {
        await whatsapp.update({
          status: "DISCONNECTED",
          qrcode: "",
          retries: 0
        });

        const updatedWhatsapp = await Whatsapp.findByPk(sessionId);
        if (updatedWhatsapp) {
          io.to("admin").emit("whatsappSession", {
            action: "update",
            session: updatedWhatsapp
          });
        }

        await removeSession(sessionId);

        return;
      }

      const shouldReconnect = statusCode !== DisconnectReason.loggedOut; // TODO handle other cases

      if (shouldReconnect) {
        await flushPendingCredsSave(sessionId);

        await whatsapp.update({ status: "OPENING" });
        io.to("admin").emit("whatsappSession", {
          action: "update",
          session: whatsapp
        });
        logger.info({
          info: "Connection closed, reconnecting...",
          sessionId,
          statusCode
        });

        await sleep(3000);
        init(whatsapp);
      }
    }

    if (connection === "open") {
      await flushPendingCredsSave(sessionId);

      await whatsapp.update({
        status: "CONNECTED",
        qrcode: "",
        retries: 0
      });

      const updatedWhatsapp = await Whatsapp.findByPk(sessionId);
      if (updatedWhatsapp) {
        io.to("admin").emit("whatsappSession", {
          action: "update",
          session: updatedWhatsapp
        });
      }

      logger.info({ info: "Session connected", sessionId });
    }

    if (qr !== undefined) {
      await whatsapp.update({
        qrcode: qr,
        status: "qrcode"
      });

      io.to("admin").emit("whatsappSession", {
        action: "update",
        session: whatsapp
      });

      logger.info({ info: "QR Code generated", sessionId });
    }
  });

  wbot.ev.on("messages.update", async updates => {
    await Promise.all(
      updates.map(async event => {
        try {
          if (!event.update.status || !event.key.id) return;

          const ack = (event.update.status as MessageAck) || 0;
          await handleMessageAck(event.key.id, ack);
        } catch (err) {
          logger.error({
            info: "Error handling message update",
            err,
            messageId: event.key.id
          });
        }
      })
    );
  });

  wbot.ev.on("message-receipt.update", async updates => {
    await Promise.all(
      updates.map(async ({ key, receipt }) => {
        try {
          if (!key.id) return;

          let ack: MessageAck = 2;
          if (receipt.playedTimestamp) {
            ack = 4;
          } else if (receipt.readTimestamp) {
            ack = 3;
          } else if (receipt.receiptTimestamp) {
            ack = 2;
          }

          await handleMessageAck(key.id, ack);

          logger.debug({
            info: "Message receipt update processed",
            messageId: key.id,
            ack,
            sessionId
          });
        } catch (err) {
          logger.error({
            info: "Error processing message receipt",
            err,
            messageId: key.id
          });
        }
      })
    );
  });
};

const shutdown = async (): Promise<void> => {
  sessions.forEach(wbot => wbot.ev.removeAllListeners("messages.upsert"));
  await Promise.all(
    Array.from(inFlightMessageHandlers).map(handler =>
      handler.catch(() => undefined)
    )
  );
  await Promise.all(Array.from(sessions.keys()).map(removeSession));
};

const logout = async (sessionId: number): Promise<void> => {
  await flushPendingCredsSave(sessionId);

  const wbot = sessions.get(sessionId);

  if (wbot) {
    await wbot
      .logout()
      .catch(err => logger.error({ info: "Error on logout", sessionId, err }));
  }

  await removeSession(sessionId);

  const whatsapp = await Whatsapp.findByPk(sessionId);

  if (whatsapp) {
    await whatsapp.update({
      status: "DISCONNECTED",
      qrcode: "",
      session: "",
      retries: 0
    });

    const updatedWhatsapp = await Whatsapp.findByPk(sessionId);
    if (updatedWhatsapp) {
      getIO().to("admin").emit("whatsappSession", {
        action: "update",
        session: updatedWhatsapp
      });
    }

    logger.info({ info: "Session logged out", sessionId });
  }

  await clearSessionKeys(sessionId);
};

const sendMessage = async (
  sessionId: number,
  to: string,
  body: string,
  options?: SendMessageOptions
): Promise<ProviderMessage> => {
  const wbot = getWbot(sessionId);
  const toJid = normalizeJid(to);

  const messageContent: AnyMessageContent = options?.quotedMessageId
    ? {
        text: body,
        contextInfo: {
          stanzaId: options.quotedMessageId,
          participant: options.quotedMessageFromMe ? wbot.user?.id : toJid
        }
      }
    : { text: body };

  const sentMsg = await wbot.sendMessage(toJid, messageContent);

  if (!sentMsg?.key.id) {
    throw new AppError("ERR_SENDING_WAPP_MSG");
  }

  msgCache.save(sentMsg);

  return {
    id: sentMsg.key.id,
    body,
    fromMe: true,
    hasMedia: false,
    type: "chat",
    timestamp: sentMsg.messageTimestamp
      ? Number(sentMsg.messageTimestamp)
      : Date.now(),
    from: wbot.user?.id || "",
    to,
    ack: 1
  };
};

const sendMedia = async (
  sessionId: number,
  to: string,
  media: ProviderMediaInput,
  options?: SendMediaOptions
): Promise<ProviderMessage> => {
  const wbot = getWbot(sessionId);
  const toJid = normalizeJid(to);

  const mediaBuffer = media.path ? readFileSync(media.path) : media.data;
  if (!mediaBuffer) throw new AppError("ERR_NO_MEDIA_DATA");

  const contextInfo = options?.quotedMessageId
    ? { stanzaId: options.quotedMessageId, participant: toJid }
    : undefined;

  const buildPayload = () => {
    const base = {
      caption: options?.caption,
      mimetype: media.mimetype,
      contextInfo
    };

    if (options?.sendAsSticker) {
      return {
        message: { sticker: mediaBuffer, contextInfo },
        type: "sticker" as MessageType
      };
    }

    if (media.mimetype.startsWith("image/")) {
      return {
        message: { image: mediaBuffer, ...base },
        type: "image" as MessageType
      };
    }

    if (media.mimetype.startsWith("video/")) {
      return {
        message: { video: mediaBuffer, ...base },
        type: "video" as MessageType
      };
    }

    if (media.mimetype.startsWith("audio/")) {
      const ptt = Boolean(options?.sendAudioAsVoice);
      return {
        message: {
          audio: mediaBuffer,
          mimetype: media.mimetype,
          ptt,
          contextInfo
        },
        type: ptt ? "ptt" : ("audio" as MessageType)
      };
    }

    return {
      message: {
        document: mediaBuffer,
        caption: options?.caption,
        mimetype: media.mimetype,
        fileName: media.filename,
        contextInfo
      },
      type: "document" as MessageType
    };
  };

  const { message, type } = buildPayload();

  const sent = await wbot.sendMessage(toJid, message);
  if (!sent?.key?.id) throw new AppError("ERR_SENDING_WAPP_MEDIA_MSG");

  msgCache.save(sent);

  return {
    id: sent.key.id,
    body: options?.caption || media.filename,
    fromMe: true,
    hasMedia: true,
    type,
    timestamp: sent.messageTimestamp
      ? Number(sent.messageTimestamp)
      : Date.now(),
    from: wbot.user?.id || "",
    to,
    ack: 1
  };
};

const deleteMessage = async (
  sessionId: number,
  chatId: string,
  messageId: string,
  fromMe: boolean
): Promise<void> => {
  const wbot = getWbot(sessionId);

  const normalizedChatId = normalizeJid(chatId);

  const key = {
    remoteJid: normalizedChatId,
    id: messageId,
    fromMe
  };

  await wbot.sendMessage(normalizedChatId, { delete: key });
};

const checkNumber = async (
  sessionId: number,
  number: string
): Promise<string> => {
  const wbot = getWbot(sessionId);

  const cleanNumber = number.replace(/\D/g, "");

  const [result] = await wbot.onWhatsApp(cleanNumber);

  if (!result?.exists) {
    throw new AppError("ERR_NUMBER_NOT_ON_WHATSAPP", 404);
  }

  return result.jid;
};

const getProfilePicUrl = async (
  sessionId: number,
  number: string
): Promise<string> => {
  const wbot = getWbot(sessionId);

  const jid = number.includes("@") ? number : `${number}@s.whatsapp.net`;

  try {
    const url = await wbot.profilePictureUrl(jid, "image");
    return url || "";
  } catch (err) {
    logger.debug({
      info: "Could not get profile picture",
      number,
      err
    });
    return "";
  }
};

const getContacts = async (sessionId: number): Promise<ProviderContact[]> => {
  const wbot = getWbot(sessionId);

  const contacts: ProviderContact[] = [];

  if (wbot.store?.contacts) {
    Object.values(wbot.store.contacts).forEach(contact => {
      if (contact.id && isJidUser(contact.id)) {
        contacts.push({
          id: contact.id,
          number: jidNormalizedUser(contact.id).replace("@s.whatsapp.net", ""),
          name: contact.name || contact.notify || "",
          pushname: contact.notify || "",
          isGroup: false
        });
      }
    });
  }

  return contacts;
};

const sendSeen = async (sessionId: number, chatId: string): Promise<void> => {
  const wbot = getWbot(sessionId);

  const normalizedChatId = normalizeJid(chatId);

  const lastMessages =
    wbot.store?.messages?.[normalizedChatId]?.array?.slice(-5) || [];

  if (lastMessages.length === 0) {
    return;
  }

  const keys = lastMessages
    .filter(msg => !msg.key.fromMe && msg.key.id)
    .map(msg => ({
      remoteJid: normalizedChatId,
      id: msg.key.id!,
      participant: msg.key.participant
    }));

  if (keys.length > 0) {
    await wbot.readMessages(keys);
  }
};

const fetchChatMessages = async (
  sessionId: number,
  chatId: string,
  limit = 100
): Promise<ProviderMessage[]> => {
  const wbot = getWbot(sessionId);

  const normalizedChatId = normalizeJid(chatId);

  const messagesFromStore =
    wbot.store?.messages?.[normalizedChatId]?.array || [];

  const messages = messagesFromStore.slice(-limit);

  return messages.map(msg => ({
    id: msg.key.id || "",
    body: getMessageBody(msg),
    fromMe: msg.key.fromMe || false,
    hasMedia: hasMedia(msg),
    type: mapMessageType(msg),
    timestamp: msg.messageTimestamp ? Number(msg.messageTimestamp) : Date.now(),
    from: msg.key.participant || msg.key.remoteJid || "",
    to: normalizedChatId,
    ack: mapMessageAck(msg.status)
  }));
};

const requestHistoryPage = async (
  wbot: Session,
  cursor: HistorySyncCursor,
  count: number
): Promise<WAMessage[]> =>
  new Promise<WAMessage[]>((resolve, reject) => {
    let settled = false;
    const cleanup = () => {
      wbot.ev.off("messages.pdo-response", onResponse);
      clearTimeout(timeout);
    };
    const finish = (messages: WAMessage[]) => {
      if (settled) return;
      settled = true;
      cleanup();
      resolve(messages);
    };
    const onResponse = ({ messages }: { messages: WAMessage[] }) => {
      finish(messages || []);
    };
    const timeout = setTimeout(() => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(new AppError("ERR_HISTORY_SYNC_TIMEOUT", 504));
    }, 15_000);

    wbot.ev.on("messages.pdo-response", onResponse);
    wbot
      .fetchMessageHistory(
        count,
        {
          remoteJid: cursor.chatId,
          id: cursor.oldestMessageId,
          fromMe: cursor.oldestMessageFromMe
        },
        cursor.oldestMessageTimestampMs
      )
      .catch(error => {
        if (settled) return;
        settled = true;
        cleanup();
        reject(error);
      });
  });

const syncHistory = async (
  sessionId: number,
  cursors: HistorySyncCursor[],
  onProgress?: (progress: HistorySyncProgress) => void
): Promise<HistorySyncResult> => {
  const wbot = getWbot(sessionId);
  const pageSize = 50;
  const maxPagesPerChat = 100;
  const contactCache = new Map<string, ContactPayload>();
  const progress: HistorySyncResult = {
    totalChats: cursors.length,
    processedChats: 0,
    importedMessages: 0,
    duplicateMessages: 0,
    failedMessages: 0,
    failedChats: 0,
    limitedChats: 0
  };
  let consecutiveChatFailures = 0;

  for (const initialCursor of cursors) {
    let cursor = initialCursor;
    let reachedEnd = false;
    let chatFailed = false;

    try {
      for (let page = 0; page < maxPagesPerChat; page += 1) {
        // eslint-disable-next-line no-await-in-loop
        const messages = await requestHistoryPage(wbot, cursor, pageSize);
        if (messages.length === 0) {
          reachedEnd = true;
          break;
        }

        const sortedMessages = [...messages].sort(
          (left, right) =>
            Number(left.messageTimestamp || 0) -
            Number(right.messageTimestamp || 0)
        );

        for (const message of sortedMessages) {
          if (
            !message.message ||
            !message.key.id ||
            !shouldHandleMessage(message)
          ) {
            continue;
          }
          try {
            // Evita baixar mídias e consultar contatos de mensagens que já
            // estão persistidas. A segunda verificação no handler protege a
            // pequena janela de concorrência entre esta leitura e o upsert.
            // eslint-disable-next-line no-await-in-loop
            const existingMessage = await Message.findByPk(message.key.id, {
              attributes: ["id"]
            });
            if (existingMessage) {
              const remoteJid = message.key.remoteJid || "";
              const isGroup = isJidGroup(remoteJid);
              const contactJid =
                !message.key.fromMe && isGroup && message.key.participant
                  ? message.key.participant
                  : remoteJid;
              // Even when the message body already exists, its current
              // WhatsApp key can carry the missing LID <-> phone mapping.
              // Reconcile only a confirmed pair; never infer or fabricate a
              // phone number from the LID itself.
              const identity = resolveWhatsAppMessageIdentity(
                contactJid,
                message.key as unknown as Record<string, unknown>,
                getExtendedContext(message) as unknown as
                  | Record<string, unknown>
                  | undefined,
                Boolean(message.key.fromMe)
              );
              if (identity.phoneJid && identity.lid && !isGroup) {
                const cacheKey = `${contactJid}|${identity.phoneJid}`;
                let reconciledPayload = contactCache.get(cacheKey);
                if (!reconciledPayload) {
                  // eslint-disable-next-line no-await-in-loop
                  reconciledPayload = await convertToContactPayload(
                    contactJid,
                    message,
                    wbot
                  );
                  contactCache.set(cacheKey, reconciledPayload);
                }
                // eslint-disable-next-line no-await-in-loop
                await CreateOrUpdateContactService({
                  ...reconciledPayload,
                  emitEvent: true
                });
              }
              progress.duplicateMessages += 1;
              continue;
            }
            // eslint-disable-next-line no-await-in-loop
            const data = await getHistoryMessageData(
              message,
              wbot,
              contactCache
            );
            // eslint-disable-next-line no-await-in-loop
            const result = await handleMessage(
              data.messagePayload,
              data.contactPayload,
              data.contextPayload,
              data.mediaPayload,
              { historySync: true }
            );
            if (result === "created") progress.importedMessages += 1;
            if (result === "duplicate") progress.duplicateMessages += 1;
          } catch (error) {
            progress.failedMessages += 1;
            logger.error({
              info: "Could not import historical WhatsApp message",
              sessionId,
              messageId: message.key.id,
              err: error
            });
          }
        }

        const oldestMessage = messages.reduce((oldest, message) =>
          Number(message.messageTimestamp || 0) <
          Number(oldest.messageTimestamp || 0)
            ? message
            : oldest
        );
        const oldestId = oldestMessage.key.id;
        if (!oldestId || oldestId === cursor.oldestMessageId) {
          reachedEnd = true;
          break;
        }

        cursor = {
          chatId: oldestMessage.key.remoteJid || cursor.chatId,
          oldestMessageId: oldestId,
          oldestMessageFromMe: Boolean(oldestMessage.key.fromMe),
          oldestMessageTimestampMs:
            Number(oldestMessage.messageTimestamp || 0) * 1000
        };

        if (messages.length < pageSize) {
          reachedEnd = true;
          break;
        }
      }
    } catch (error) {
      chatFailed = true;
      progress.failedChats += 1;
      consecutiveChatFailures += 1;
      logger.warn({
        info: "WhatsApp history request failed for chat",
        sessionId,
        chatId: cursor.chatId,
        err: error
      });
      if (consecutiveChatFailures >= 3) {
        throw new AppError("ERR_HISTORY_SYNC_UNAVAILABLE", 503);
      }
    }

    if (!chatFailed) consecutiveChatFailures = 0;
    if (!reachedEnd) progress.limitedChats += 1;
    progress.processedChats += 1;
    onProgress?.(progress);

    // Mantém a sincronização leve para não disputar recursos com mensagens ao vivo.
    // eslint-disable-next-line no-await-in-loop
    await sleep(250);
  }

  return progress;
};

export const WhaileysProvider: WhatsappProvider = {
  init,
  removeSession,
  shutdown,
  logout,
  sendMessage,
  sendMedia,
  deleteMessage,
  checkNumber,
  getProfilePicUrl,
  getContacts,
  sendSeen,
  fetchChatMessages,
  syncHistory
};
