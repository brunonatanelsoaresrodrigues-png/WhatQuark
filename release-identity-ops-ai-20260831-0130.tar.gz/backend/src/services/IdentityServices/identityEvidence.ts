import { createHash } from "crypto";
import { Op } from "sequelize";
import Contact from "../../models/Contact";
import QuarkAppointment from "../../models/QuarkAppointment";
import { isTechnicalContactName } from "../../helpers/ContactIdentity";
import {
  quarkCpfFrom,
  quarkPatientIdFrom,
  quarkPhoneVariants
} from "../QuarkClinicServices/appointmentUtils";
import { QuarkAppointmentDto } from "../QuarkClinicServices/types";

export interface QuarkIdentityCandidate {
  patientId: string;
  patientName: string;
  cpf: string | null;
  appointmentId: string;
  scheduledAt: Date | null;
}

export const valueHash = (value: unknown): string | null => {
  if (value === undefined || value === null || value === "") return null;
  const serialized = typeof value === "string" ? value : JSON.stringify(value);
  return createHash("sha256").update(serialized).digest("hex");
};

export const issueFingerprint = (
  contactId: number,
  type: string,
  discriminator = ""
): string =>
  createHash("sha256")
    .update(`${contactId}:${type}:${discriminator}`)
    .digest("hex");

export const safeJson = (value: unknown): string => JSON.stringify(value);

export const parseSnapshot = (
  value: string | null | undefined
): Record<string, unknown> => {
  try {
    return JSON.parse(value || "{}") as Record<string, unknown>;
  } catch {
    return {};
  }
};

export const cpfFromAppointment = (
  appointment: QuarkAppointment
): string | null =>
  quarkCpfFrom(
    parseSnapshot(appointment.snapshot) as unknown as QuarkAppointmentDto
  );

export const maskedCpf = (cpf: string | null): string | null =>
  cpf ? `***.***.***-${cpf.slice(-2)}` : null;

export const contactHasTechnicalName = (contact: Contact): boolean =>
  isTechnicalContactName(contact.name, contact.number, contact.lid);

export const contactHasUnresolvedLid = (contact: Contact): boolean => {
  const number = String(contact.number || "").replace(/\D/g, "");
  const lid = String(contact.lid || "")
    .replace(/@lid$/i, "")
    .replace(/\D/g, "");
  return Boolean(number && lid && number === lid);
};

export const findQuarkCandidates = async (
  contact: Pick<Contact, "number">
): Promise<QuarkIdentityCandidate[]> => {
  const variants = quarkPhoneVariants(String(contact.number || ""));
  if (!variants.length) return [];
  const rows = await QuarkAppointment.findAll({
    where: {
      [Op.or]: [
        { phone: { [Op.in]: variants } },
        ...variants.map(phone => ({ phones: { [Op.like]: `%${phone}%` } }))
      ]
    },
    order: [["scheduledAt", "DESC"]]
  });
  const candidates = new Map<string, QuarkIdentityCandidate>();
  rows.forEach(row => {
    const patientId = quarkPatientIdFrom(row.patientId);
    if (!patientId || candidates.has(patientId)) return;
    candidates.set(patientId, {
      patientId,
      patientName: row.patientName || "Paciente",
      cpf: cpfFromAppointment(row),
      appointmentId: row.appointmentId,
      scheduledAt: row.scheduledAt
    });
  });
  return Array.from(candidates.values());
};
