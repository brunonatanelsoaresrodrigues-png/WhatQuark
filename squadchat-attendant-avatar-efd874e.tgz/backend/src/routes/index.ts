import { Router } from "express";

import userRoutes from "./userRoutes";
import authRoutes from "./authRoutes";
import settingRoutes from "./settingRoutes";
import contactRoutes from "./contactRoutes";
import ticketRoutes from "./ticketRoutes";
import whatsappRoutes from "./whatsappRoutes";
import messageRoutes from "./messageRoutes";
import whatsappSessionRoutes from "./whatsappSessionRoutes";
import queueRoutes from "./queueRoutes";
import quickAnswerRoutes from "./quickAnswerRoutes";
import apiRoutes from "./apiRoutes";
import quarkDashboardRoutes from "./quarkDashboardRoutes";
import dailyReportRoutes from "./dailyReportRoutes";
import stickerRoutes from "./stickerRoutes";

import messagingRoutes from "./messagingRoutes";

const routes = Router();
routes.use(messagingRoutes);

routes.use(userRoutes);
routes.use("/auth", authRoutes);
routes.use(settingRoutes);
routes.use(contactRoutes);
routes.use(ticketRoutes);
routes.use(whatsappRoutes);
routes.use(messageRoutes);
routes.use(whatsappSessionRoutes);
routes.use(queueRoutes);
routes.use(quickAnswerRoutes);
routes.use(quarkDashboardRoutes);
routes.use(dailyReportRoutes);
routes.use(stickerRoutes);
routes.use("/api/messages", apiRoutes);

export default routes;
